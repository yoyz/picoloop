These are Visual C++ projects for ds2wav.dll

.dsw = Visual C++ 6
.sln = Visual C++ 7


