These are Visual Basic 5.0 project files for the DrumSynth 2.0 user interface.
