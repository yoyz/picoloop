These are Microsoft Help Compiler files for the DrumSynth 2.0 help file.
